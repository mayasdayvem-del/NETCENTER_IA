package com.netcenter.ia

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val green = Color.rgb(30, 150, 75)
    private val dark = Color.rgb(12, 22, 16)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun setup(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(247, 250, 247))
        }
        val header = TextView(this).apply {
            text = "◉  $title"
            textSize = 25f
            setTextColor(dark)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 24)
        }
        root.addView(header)
        content = root
        return root
    }

    private fun addText(root: LinearLayout, text: String, size: Float = 16f) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(45, 55, 48))
            setPadding(8, 10, 8, 14)
        })
    }

    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            isAllCaps = false
            setPadding(8, 12, 8, 12)
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 8) })
    }

    private fun showHome() {
        val root = setup("NETCENTER IA")
        addText(root, "SEGURIDAD INTELIGENTE  •  ASISTENTE PERSONAL", 12f)
        addText(root, "Tu centro de herramientas digitales", 18f)
        addButton(root, "Escáner web") { showWeb() }
        addButton(root, "Escáner de APK") { showApk() }
        addButton(root, "Agente IA general") { showAgent() }
        addText(root, "Versión de demostración 1.0\nLos análisis se habilitarán por módulos. No se muestran resultados ficticios.", 13f)
        setContentView(root)
    }

    private fun page(title: String, description: String) {
        val root = setup(title)
        addText(root, description)
        addButton(root, "Volver al inicio") { showHome() }
        setContentView(root)
    }

    private fun showWeb() {
        val root = setup("Escáner web")
        addText(root, "Introduce una dirección de un sitio que sea tuyo o que tengas autorización para evaluar.")
        val url = EditText(this).apply {
            hint = "https://ejemplo.com"
            inputType = 17
        }
        root.addView(url, LinearLayout.LayoutParams(-1, -2))
        addButton(root, "Preparar análisis") {
            val value = url.text.toString().trim()
            if (!value.startsWith("https://")) {
                Toast.makeText(this, "Introduce una dirección HTTPS válida.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Módulo de análisis web pendiente de conexión.", Toast.LENGTH_LONG).show()
            }
        }
        addText(root, "Estado: módulo en preparación. Esta versión no ejecuta pruebas ni inventa vulnerabilidades.")
        addButton(root, "Volver al inicio") { showHome() }
        setContentView(root)
    }

    private fun showApk() {
        page("Escáner de APK", "El módulo permitirá seleccionar un APK y revisar permisos y configuraciones. En esta versión la inspección todavía no está conectada.")
    }

    private fun showAgent() {
        val root = setup("Agente IA general")
        addText(root, "Asistente general para preguntas, explicaciones, redacción y ayuda tecnológica.")
        val prompt = EditText(this).apply {
            hint = "Escribe tu pregunta..."
            minLines = 3
            gravity = Gravity.TOP
        }
        root.addView(prompt, LinearLayout.LayoutParams(-1, -2))
        addButton(root, "Enviar pregunta") {
            Toast.makeText(this, "Para responder con IA real falta configurar un proveedor y una clave API segura.", Toast.LENGTH_LONG).show()
        }
        addText(root, "La conexión con un modelo de IA se añadirá en una siguiente versión. No se simulan respuestas.")
        addButton(root, "Volver al inicio") { showHome() }
        setContentView(root)
    }
}
