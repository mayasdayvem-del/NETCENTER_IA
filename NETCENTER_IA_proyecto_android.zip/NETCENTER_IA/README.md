# NETCENTER IA — proyecto Android inicial

Este proyecto crea una app Android con tres módulos visibles:
- Escáner web (interfaz preparada; análisis aún no conectado).
- Escáner de APK (interfaz preparada; análisis aún no conectado).
- Agente IA general (interfaz preparada; requiere conectar un proveedor de IA).

## Compilar el APK desde el teléfono usando GitHub Actions
1. Crea una cuenta en GitHub si no tienes una.
2. Crea un repositorio nuevo y sube el contenido completo de este ZIP.
3. Abre la pestaña **Actions** del repositorio.
4. Ejecuta **Build NETCENTER IA APK** con **Run workflow**.
5. Al terminar, descarga el artefacto `NETCENTER-IA-debug`.
6. Descomprime el artefacto e instala `app-debug.apk` en tu Android. Permite instalar desde esa fuente si Android lo solicita.

## Importante
Esta es una primera versión de interfaz. No realiza escaneos reales ni ofrece respuestas generadas por IA todavía. Los siguientes módulos requieren implementaciones y pruebas separadas. Usa el escáner únicamente con activos propios o con autorización expresa.

## Logotipo
El código inicial muestra un símbolo provisional. Para integrar el logotipo original, coloca una versión PNG cuadrada en `app/src/main/res/drawable/` y actualiza el encabezado/icono. La imagen original no se ha incrustado en este paquete porque no hay un archivo de imagen disponible en el espacio de trabajo actual.
